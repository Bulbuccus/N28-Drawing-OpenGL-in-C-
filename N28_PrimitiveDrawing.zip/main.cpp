﻿#include <GL/glut.h>
#include <stdlib.h>
#include <math.h>

/** Muhammad Imran Haziq Bin Noor Azhar **/
/** A21EC0206				SECV2213-01 **/
/** Assignment 1B			9/5/2023	**/

void init(void)
{
	glClearColor(0.6f, 0.6f, 0.6f, 0.5f); // Clear the background to dark grey
	glEnable(GL_POINT_SMOOTH); // Enable the points becomes circle
	glMatrixMode(GL_PROJECTION); // Use the Projection Matrix
	gluOrtho2D(0.0, 1600.0, 0.0, 800.0); // Sets up a two-dimensional orthographic viewing region.
}

void changeSize(int w, int h) {

	// Prevent a divide by zero, when window is too short
	// (you cant make a window of zero width).
	if (h == 0)
		h = 1;

	float ratio = w * 1.0 / h;

	// Set the viewport to be the entire window
	glViewport(0, 0, w, h);

	// Use the Projection Matrix
	glMatrixMode(GL_PROJECTION);

	// Reset Matrix
	glLoadIdentity();

	// Set the correct perspective.
	gluPerspective(45, ratio, 1, 100);

}

void Sky() {
	glBegin(GL_QUADS);
	glColor3f(0.35, 0.7, 1.0);// Light blue
	glVertex2f(-1.0, 0.2);
	glColor3f(0, 0.501, 1.0);// Blue
	glVertex2f(-1.0, 1.0);
	glVertex2f(1.0, 1.0);
	glColor3f(0.5, 0.75, 1.0);// Light blue
	glVertex2f(1.0, 0.2);
	glEnd();
}

void Grassfield() {
	
	glColor3f(0.42f, 0.57f, 0.137f);// Green
	glBegin(GL_QUADS);
	glVertex2f(1, -0.55);
	glVertex2f(0.22, -0.55);
	glVertex2f(0.22, -0.8);
	glVertex2f(1.0, -0.8);
	glEnd();

	//Grass 1
	glColor3f(0.0f, 0.8f, 0.0f);// Grseen
	glBegin(GL_TRIANGLES);
	glVertex2f(0.33, -0.68);
	glVertex2f(0.35, -0.68);
	glVertex2f(0.34, -0.64);
	glVertex2f(0.33, -0.68);
	glVertex2f(0.35, -0.68);
	glVertex2f(0.31, -0.65);
	glVertex2f(0.33, -0.68);
	glVertex2f(0.35, -0.68);
	glVertex2f(0.36, -0.66);

	//Grass 2
	glColor3f(0.0f, 0.8f, 0.0f);// Grseen
	glBegin(GL_TRIANGLES);
	glVertex2f(0.39, -0.8);
	glVertex2f(0.41, -0.8);
	glVertex2f(0.40, -0.76);
	glVertex2f(0.39, -0.8);
	glVertex2f(0.41, -0.8);
	glVertex2f(0.38, -0.77);
	glVertex2f(0.39, -0.8);
	glVertex2f(0.41, -0.8);
	glVertex2f(0.42, -0.75);

	//Grass 3
	glColor3f(0.0f, 0.8f, 0.0f);// Grseen
	glBegin(GL_TRIANGLES);
	glVertex2f(0.7, -0.675);
	glVertex2f(0.72, -0.675);
	glVertex2f(0.71, -0.650);
	glVertex2f(0.7, -0.675);
	glVertex2f(0.72, -0.675);
	glVertex2f(0.69, -0.660);
	glVertex2f(0.7, -0.675);
	glVertex2f(0.72, -0.675);
	glVertex2f(0.74, -0.640);
}

void Road() {

	glColor3f(0.2f, 0.2f, 0.2f);// Dark Grey
	glBegin(GL_QUADS);
	glVertex2f(1, -0.8);
	glVertex2f(-1, -0.8);
	glVertex2f(-1, -1);
	glVertex2f(1, -1);
	glEnd();

}
void Circle1(float x, float y, double r) {
	float x1, y1;
	glBegin(GL_POLYGON);
	for (int i = 0; i < 200; i++) {
		float pi = 3.1416;
		float A = (i * pi * 2) / 25;
		float x1 = x + ((r - 0.07) * cos(A));
		float y1 = y + ((r)*sin(A));
		glVertex2f(x1, y1);
	}
	glEnd();
}

void Cloud1() {
	glColor3f(0.8, 0.9, 1.0); // Light blue
	Circle1(0.85, 0.77, 0.15);
	Circle1(0.90, 0.70, 0.15);
	Circle1(0.80, 0.70, 0.15);
	Circle1(0.75, 0.77, 0.15);
	Circle1(0.70, 0.70, 0.15);
}

void Sun() {
	glColor3f(1.0f, 0.8f, 0.4f); // Light orange
	Circle1(-0.95, 0.90, 0.30);
}

void Building() {
	// Top Back-Front side wall
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_QUADS); 
	glVertex2f(0.15, 0.7); // Top Right Vertice
	glVertex2f(-0.15, 0.7); // Top Left Vertice
	glVertex2f(-0.15, 0.2); // Bottom Left Vertice
	glVertex2f(0.15, 0.2); // Bottom Right Vertice
	glEnd();

	// Top Inner Fore-Front side wall
	glColor3f(0.4f, 0.89f, 0.75f); // Custom color : #65E5C0 (R=101, G=229, B=192)
	glBegin(GL_QUADS);
	glVertex2f(0.13, 0.6); // Top Right Vertex
	glVertex2f(-0.13, 0.6);// Top Left Vertex
	glVertex2f(-0.13, 0.4);// Bottom Left Vertex
	glVertex2f(0.13, 0.4); // Bottom Right Vertex
	glEnd();

	// Top Block Number Lettering
	glColor3f(0.0f, 0.0f, 0.0f);// Black
	//Letter "N"
	glBegin(GL_QUADS);
	glVertex2f(-0.11, 0.57);
	glVertex2f(-0.09, 0.57);
	glVertex2f(-0.09, 0.45);
	glVertex2f(-0.11, 0.45);

	glBegin(GL_QUADS);
	glVertex2f(-0.11, 0.57);
	glVertex2f(-0.09, 0.57);
	glVertex2f(-0.05, 0.45);
	glVertex2f(-0.07, 0.45);

	glBegin(GL_QUADS);
	glVertex2f(-0.07, 0.57);
	glVertex2f(-0.05, 0.57);
	glVertex2f(-0.05, 0.45);
	glVertex2f(-0.07, 0.45);

	// Numerical "2"
	glBegin(GL_QUADS);
	glVertex2f(-0.03, 0.57);
	glVertex2f(-0.01, 0.57);
	glVertex2f(-0.01, 0.55);
	glVertex2f(-0.03, 0.55);

	glBegin(GL_QUADS);
	glVertex2f(-0.03, 0.57);
	glVertex2f(-0.04, 0.55);
	glVertex2f(-0.04, 0.53);
	glVertex2f(-0.03, 0.55);

	glBegin(GL_QUADS);
	glVertex2f(0, 0.55);
	glVertex2f(-0.03, 0.57);
	glVertex2f(-0.03, 0.56);
	glVertex2f(0, 0.54);

	glBegin(GL_QUADS);
	glVertex2f(0, 0.55);
	glVertex2f(-0.01, 0.55);
	glVertex2f(-0.04, 0.45);
	glVertex2f(-0.03, 0.45);

	glBegin(GL_QUADS);
	glVertex2f(0, 0.46);
	glVertex2f(-0.04, 0.46);
	glVertex2f(-0.04, 0.45);
	glVertex2f(0, 0.45);

	//Numerical "8"
	glBegin(GL_QUADS);
	glVertex2f(0.05, 0.57);
	glVertex2f(0.02, 0.57);
	glVertex2f(0.02, 0.55);
	glVertex2f(0.05, 0.55);

	glBegin(GL_QUADS);
	glVertex2f(0.06, 0.55);
	glVertex2f(0.05, 0.55);
	glVertex2f(0.05, 0.52);
	glVertex2f(0.06, 0.52);

	glBegin(GL_QUADS);
	glVertex2f(0.05, 0.52);
	glVertex2f(0.02, 0.52);
	glVertex2f(0.02, 0.50);
	glVertex2f(0.05, 0.50);

	glBegin(GL_QUADS);
	glVertex2f(0.02, 0.55);
	glVertex2f(0.01, 0.55);
	glVertex2f(0.01, 0.52);
	glVertex2f(0.02, 0.52);

	glBegin(GL_QUADS);
	glVertex2f(0.06, 0.50);
	glVertex2f(0.05, 0.50);
	glVertex2f(0.05, 0.47);
	glVertex2f(0.06, 0.47);

	glBegin(GL_QUADS);
	glVertex2f(0.05, 0.47);
	glVertex2f(0.02, 0.47);
	glVertex2f(0.02, 0.45);
	glVertex2f(0.05, 0.45);

	glBegin(GL_QUADS);
	glVertex2f(0.02, 0.50);
	glVertex2f(0.01, 0.50);
	glVertex2f(0.01, 0.47);
	glVertex2f(0.02, 0.47);
	glEnd();

	// Second top wall
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_QUADS);
	glVertex2f(0.23, 0.3);
	glVertex2f(-0.23, 0.3);
	glVertex2f(-0.23, -0.2);
	glVertex2f(0.23, -0.2);
	glEnd();

	// Window Section (Upper)
	glBegin(GL_QUADS);
	glColor4f(0.0f, 0.0f, 0.5f, 1.0f);// Navy blue
	glVertex2f(0.22, 0.28); // Top Right Vertex
	glColor3f(1.0, 1.0, 1.0); // White
	glVertex2f(0.22, 0.10);  // Bottom Right Vertex
	glColor4f(0.0f, 0.0f, 0.5f, 1.0f);// Navy blue
	glVertex2f(-0.22, 0.10); // Bottom Left Vertex
	glColor3f(1.0, 1.0, 1.0); // White
	glVertex2f(-0.22, 0.28); // Top Left Vertex
	glEnd();

	// Window Section (Lower)
	glBegin(GL_QUADS);
	glColor4f(0.0f, 0.0f, 0.5f, 1.0f);// Navy blue
	glVertex2f(0.22, 0); // Top Right Vertex
	glColor3f(1.0, 1.0, 1.0); // White
	glVertex2f(0.22, -0.18);  // Bottom Right Vertex
	glColor4f(0.0f, 0.0f, 0.5f, 1.0f);// Navy blue
	glVertex2f(-0.22, -0.18); // Bottom Left Vertex
	glColor3f(1.0, 1.0, 1.0); // White
	glVertex2f(-0.22, 0); // Top Left Vertex
	glEnd();

	// Inner second top upper section - Left strip(1)
	glColor3f(0.5f, 0.5f, 0.5f);// Grey
	glBegin(GL_QUADS);
	glVertex2f(-0.22, 0.28);
	glVertex2f(-0.19, 0.28);
	glVertex2f(-0.19, 0.10);
	glVertex2f(-0.22, 0.10);
	glEnd();

	// Border Lines
	glColor3f(1.0f, 1.0f, 1.0f); //White
	glBegin(GL_LINES);
	glVertex2f(-0.22, 0.28);
	glVertex2d(-0.22, 0.10);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f); //White
	glBegin(GL_LINES);
	glVertex2f(-0.19, 0.28);
	glVertex2d(-0.19, 0.10);
	glEnd();

	// Inner second top upper section - Left strip(2)
	glColor3f(0.5f, 0.5f, 0.5f);// Grey
	glBegin(GL_QUADS);
	glVertex2f(-0.16, 0.28);
	glVertex2f(-0.13, 0.28);
	glVertex2f(-0.13, 0.10);
	glVertex2f(-0.16, 0.10);
	glEnd();

	// Border Lines
	glColor3f(1.0f, 1.0f, 1.0f); //White
	glBegin(GL_LINES);
	glVertex2f(-0.16, 0.28);
	glVertex2d(-0.16, 0.10);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f); //White
	glBegin(GL_LINES);
	glVertex2f(-0.13, 0.28);
	glVertex2d(-0.13, 0.10);
	glEnd();

	// Inner second top upper section - Left strip(3)
	glColor3f(0.5f, 0.5f, 0.5f);// Grey
	glBegin(GL_QUADS);
	glVertex2f(-0.10, 0.28);
	glVertex2f(-0.07, 0.28);
	glVertex2f(-0.07, 0.10);
	glVertex2f(-0.10, 0.10);
	glEnd();

	// Border Lines
	glColor3f(1.0f, 1.0f, 1.0f); //White
	glBegin(GL_LINES);
	glVertex2f(-0.10, 0.28);
	glVertex2d(-0.10, 0.10);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f); //White
	glBegin(GL_LINES);
	glVertex2f(-0.07, 0.28);
	glVertex2d(-0.07, 0.10);
	glEnd();

	// Inner second top upper section - Right strip(1)
	glColor3f(0.5f, 0.5f, 0.5f);// Grey
	glBegin(GL_QUADS);
	glVertex2f(0.22, 0.28);
	glVertex2f(0.19, 0.28);
	glVertex2f(0.19, 0.10);
	glVertex2f(0.22, 0.10);
	glEnd();

	// Border Lines
	glColor3f(1.0f, 1.0f, 1.0f); //White
	glBegin(GL_LINES);
	glVertex2f(0.22, 0.28);
	glVertex2d(0.22, 0.10);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f); //White
	glBegin(GL_LINES);
	glVertex2f(0.19, 0.28);
	glVertex2d(0.19, 0.10);
	glEnd();

	// Inner second top upper section - Right strip(2)
	glColor3f(0.5f, 0.5f, 0.5f);// Grey
	glBegin(GL_QUADS);
	glVertex2f(0.16, 0.28);
	glVertex2f(0.13, 0.28);
	glVertex2f(0.13, 0.10);
	glVertex2f(0.16, 0.10);
	glEnd();

	// Border Lines
	glColor3f(1.0f, 1.0f, 1.0f); //White
	glBegin(GL_LINES);
	glVertex2f(0.16, 0.28);
	glVertex2d(0.16, 0.10);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f); //White
	glBegin(GL_LINES);
	glVertex2f(0.13, 0.28);
	glVertex2d(0.13, 0.10);
	glEnd();

	// Inner second top upper section - Right strip(3)
	glColor3f(0.5f, 0.5f, 0.5f);// Grey
	glBegin(GL_QUADS);
	glVertex2f(0.10, 0.28);
	glVertex2f(0.07, 0.28);
	glVertex2f(0.07, 0.10);
	glVertex2f(0.10, 0.10);
	glEnd();

	// Border Lines
	glColor3f(1.0f, 1.0f, 1.0f); //White
	glBegin(GL_LINES);
	glVertex2f(0.10, 0.28);
	glVertex2d(0.10, 0.10);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f); //White
	glBegin(GL_LINES);
	glVertex2f(0.07, 0.28);
	glVertex2d(0.07, 0.10);
	glEnd();

	//Inner second top upper section - Middle square lines
	glColor3f(1.0f, 1.0f, 1.0f);// White
	glBegin(GL_LINES);
	glVertex2f(-0.07, 0.28);
	glVertex2f(0.07, 0.10);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f);// White
	glBegin(GL_LINES);
	glVertex2f(-0.07, 0.10);
	glVertex2f(0.07, 0.28);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f);// White
	glBegin(GL_LINES);
	glVertex2f(0, 0.28);
	glVertex2f(0.07, 0.19);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f);// White
	glBegin(GL_LINES);
	glVertex2f(0.07, 0.19);
	glVertex2f(0, 0.10);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f);// White
	glBegin(GL_LINES);
	glVertex2f(0, 0.10);
	glVertex2f(-0.07, 0.19);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f);// White
	glBegin(GL_LINES);
	glVertex2f(-0.07, 0.19);
	glVertex2f(0, 0.28);
	glEnd();

	// Second top middle section
	glColor3f(0.4f, 0.89f, 0.75f); // Custom color : #65E5C0 (R=101, G=229, B=192)
	glBegin(GL_QUADS);
	glVertex2f(0.22, 0.10);
	glVertex2f(-0.22, 0.10);
	glVertex2f(-0.22, 0);
	glVertex2f(0.22, 0);
	glEnd();

	// Inner second top lower section - Left strip(1)
	glColor3f(0.5f, 0.5f, 0.5f);// Grey
	glBegin(GL_QUADS);
	glVertex2f(-0.22, 0);
	glVertex2f(-0.19, 0);
	glVertex2f(-0.19, -0.18);
	glVertex2f(-0.22, -0.18);
	glEnd();

	// Border Lines
	glColor3f(1.0f, 1.0f, 1.0f); //White
	glBegin(GL_LINES);
	glVertex2f(-0.22, 0);
	glVertex2d(-0.22, -0.18);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f); //White
	glBegin(GL_LINES);
	glVertex2f(-0.19, 0);
	glVertex2d(-0.19, -0.18);
	glEnd();

	// Inner second top lower section - Left strip(2)
	glColor3f(0.5f, 0.5f, 0.5f);// Grey
	glBegin(GL_QUADS);
	glVertex2f(-0.16, 0);
	glVertex2f(-0.13, 0);
	glVertex2f(-0.13, -0.18);
	glVertex2f(-0.16, -0.18);
	glEnd();

	// Border Lines
	glColor3f(1.0f, 1.0f, 1.0f); //White
	glBegin(GL_LINES);
	glVertex2f(-0.16, 0);
	glVertex2d(-0.16, -0.18);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f); //White
	glBegin(GL_LINES);
	glVertex2f(-0.13, 0);
	glVertex2d(-0.13, -0.18);
	glEnd();

	// Inner second top lower section - Left strip(3)
	glColor3f(0.5f, 0.5f, 0.5f);// Grey
	glBegin(GL_QUADS);
	glVertex2f(-0.10, 0);
	glVertex2f(-0.07, 0);
	glVertex2f(-0.07, -0.18);
	glVertex2f(-0.10, -0.18);
	glEnd();

	// Border Lines
	glColor3f(1.0f, 1.0f, 1.0f); //White
	glBegin(GL_LINES);
	glVertex2f(-0.10, 0);
	glVertex2d(-0.10, -0.18);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f); //White
	glBegin(GL_LINES);
	glVertex2f(-0.07, 0);
	glVertex2d(-0.07, -0.18);
	glEnd();

	// Inner second top lower section - Right strip(1)
	glColor3f(0.5f, 0.5f, 0.5f);// Grey
	glBegin(GL_QUADS);
	glVertex2f(0.22, 0);
	glVertex2f(0.19, 0);
	glVertex2f(0.19, -0.18);
	glVertex2f(0.22, -0.18);
	glEnd();

	// Border Lines
	glColor3f(1.0f, 1.0f, 1.0f); //White
	glBegin(GL_LINES);
	glVertex2f(0.22, 0);
	glVertex2d(0.22, -0.18);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f); //White
	glBegin(GL_LINES);
	glVertex2f(0.19, 0);
	glVertex2d(0.19, -0.18);
	glEnd();

	// Inner second top lower section - Right strip(2)
	glColor3f(0.5f, 0.5f, 0.5f);// Grey
	glBegin(GL_QUADS);
	glVertex2f(0.16, 0);
	glVertex2f(0.13, 0);
	glVertex2f(0.13, -0.18);
	glVertex2f(0.16, -0.18);
	glEnd();

	// Border Lines
	glColor3f(1.0f, 1.0f, 1.0f); //White
	glBegin(GL_LINES);
	glVertex2f(0.16, 0);
	glVertex2d(0.16, -0.18);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f); //White
	glBegin(GL_LINES);
	glVertex2f(0.13, 0);
	glVertex2d(0.13, -0.18);
	glEnd();

	// Inner second top lower section - Right strip(3)
	glColor3f(0.5f, 0.5f, 0.5f);// Grey
	glBegin(GL_QUADS);
	glVertex2f(0.10, 0);
	glVertex2f(0.07, 0);
	glVertex2f(0.07, -0.18);
	glVertex2f(0.10, -0.18);
	glEnd();

	// Border Lines
	glColor3f(1.0f, 1.0f, 1.0f); //White
	glBegin(GL_LINES);
	glVertex2f(0.10, 0);
	glVertex2d(0.10, -0.18);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f); //White
	glBegin(GL_LINES);
	glVertex2f(0.07, 0);
	glVertex2d(0.07, -0.18);
	glEnd();

	//Inner second top lower section - Middle square lines
	glColor3f(1.0f, 1.0f, 1.0f);// White
	glBegin(GL_LINES);
	glVertex2f(-0.07, 0);
	glVertex2f(0.07, -0.18);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f);// White
	glBegin(GL_LINES);
	glVertex2f(-0.07, -0.18);
	glVertex2f(0.07, 0);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f);// White
	glBegin(GL_LINES);
	glVertex2f(0, 0);
	glVertex2f(0.07, -0.09);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f);// White
	glBegin(GL_LINES);
	glVertex2f(0.07, -0.09);
	glVertex2f(0, -0.18);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f);// White
	glBegin(GL_LINES);
	glVertex2f(0, -0.18);
	glVertex2f(-0.07, -0.09);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f);// White
	glBegin(GL_LINES);
	glVertex2f(-0.07, -0.09);
	glVertex2f(0, 0);
	glEnd();

	//Right Wing
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_QUADS);
	glVertex2f(0.46, 0.2);
	glVertex2f(0.23, 0.3);
	glVertex2f(0.23, -0.2);
	glVertex2f(0.46, -0.3);
	glEnd();

	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_QUADS);
	glVertex2f(1, 0.4);
	glVertex2f(0.46, 0.2);
	glVertex2f(0.46, -0.3);
	glVertex2f(1, -0.1);
	glEnd();

	// First Section
	glColor3f(0.5f, 0.5f, 0.5f);// Grey
	glBegin(GL_QUADS);
	glVertex2f(0.45, 0.18); //Top right vertice
	glVertex2f(0.23, 0.28); // Top left vertice
	glVertex2f(0.23, 0.21); // Bottom left vertice
	glVertex2f(0.45, 0.11); // Bottom right vertice
	glEnd();

	glColor3f(0.0f, 0.0f, 0.0f);// Black
	glBegin(GL_QUADS);
	glVertex2f(0.45, 0.11);
	glVertex2f(0.23, 0.21);
	glVertex2f(0.23, 0.10);
	glVertex2f(0.45, 0);
	glEnd();

	glColor3f(0.4f, 0.89f, 0.75f); // Custom color : #65E5C0 (R=101, G=229, B=192)
	glBegin(GL_QUADS);
	glVertex2f(0.45, 0);
	glVertex2f(0.23, 0.10);
	glVertex2f(0.23, 0);
	glVertex2f(0.45, -0.10);
	glEnd();

	glColor3f(0.5f, 0.5f, 0.5f);// Grey
	glBegin(GL_QUADS);
	glVertex2f(0.45, -0.10); //Top right vertice
	glVertex2f(0.23, 0); // Top left vertice
	glVertex2f(0.23, -0.08); // Bottom left vertice
	glVertex2f(0.45, -0.18); // Bottom right vertice
	glEnd();

	glColor3f(0.0f, 0.0f, 0.0f);// Black
	glBegin(GL_QUADS);
	glVertex2f(0.45, -0.18);
	glVertex2f(0.23, -0.08);
	glVertex2f(0.23, -0.18);
	glVertex2f(0.45, -0.28);
	glEnd();

	// Second Section
	glColor3f(0.5f, 0.5f, 0.5f);// Grey
	glBegin(GL_QUADS);
	glVertex2f(1, 0.38); //Top right vertice
	glVertex2f(0.45, 0.18); // Top left vertice
	glVertex2f(0.45, 0.11); // Bottom left vertice
	glVertex2f(1, 0.31); // Bottom right vertice
	glEnd();

	glColor3f(0.0f, 0.0f, 0.0f);// Black
	glBegin(GL_QUADS);
	glVertex2f(1, 0.31);
	glVertex2f(0.45, 0.11);
	glVertex2f(0.45, 0);
	glVertex2f(1, 0.20);
	glEnd();

	glColor3f(0.4f, 0.89f, 0.75f); // Custom color : #65E5C0 (R=101, G=229, B=192)
	glBegin(GL_QUADS);
	glVertex2f(1, 0.20);
	glVertex2f(0.45, 0);
	glVertex2f(0.45, -0.10);
	glVertex2f(1, 0.09);
	glEnd();

	glColor3f(0.5f, 0.5f, 0.5f);// Grey
	glBegin(GL_QUADS);
	glVertex2f(1, 0.09); //Top right vertice
	glVertex2f(0.45, -0.10); // Top left vertice
	glVertex2f(0.45, -0.18); // Bottom left vertice
	glVertex2f(1, 0.01); // Bottom right vertice
	glEnd();

	glColor3f(0.0f, 0.0f, 0.0f);// Black
	glBegin(GL_QUADS);
	glVertex2f(1, 0.01);
	glVertex2f(0.45, -0.18);
	glVertex2f(0.45, -0.28);
	glVertex2f(1, -0.08);
	glEnd();

	//Pillar 1
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_QUADS);
	glVertex2f(0.34, 0.24);
	glVertex2f(0.33, 0.25);
	glVertex2f(0.33, -0.24);
	glVertex2f(0.34, -0.25);
	glEnd();

	//Pillar 2
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_QUADS);
	glVertex2f(0.64, 0.26);
	glVertex2f(0.63, 0.25);
	glVertex2f(0.63, -0.24);
	glVertex2f(0.64, -0.23);
	glEnd();

	//Pillar 3
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_QUADS);
	glVertex2f(0.82, 0.32);
	glVertex2f(0.83, 0.33);
	glVertex2f(0.83, -0.15);
	glVertex2f(0.82, -0.16);
	glEnd();

	//Left Wing
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_QUADS);
	glVertex2f(-0.47, 0.2);
	glVertex2f(-0.23, 0.3);
	glVertex2f(-0.23, -0.2);
	glVertex2f(-0.46, -0.3);
	glEnd();

	glColor3f(0.5f, 0.5f, 0.5f);// Grey
	glBegin(GL_QUADS);
	glVertex2f(-0.45, 0.18); //Top right vertice
	glVertex2f(-0.23, 0.28); // Top left vertice
	glVertex2f(-0.23, 0.21); // Bottom left vertice
	glVertex2f(-0.45, 0.11); // Bottom right vertice
	glEnd();

	glColor3f(0.0f, 0.0f, 0.0f);// Black
	glBegin(GL_QUADS);
	glVertex2f(-0.45, 0.11);
	glVertex2f(-0.23, 0.21);
	glVertex2f(-0.23, 0.10);
	glVertex2f(-0.45, 0);
	glEnd();

	glColor3f(0.4f, 0.89f, 0.75f); // Custom color : #65E5C0 (R=101, G=229, B=192)
	glBegin(GL_QUADS);
	glVertex2f(-0.45, 0);
	glVertex2f(-0.23, 0.10);
	glVertex2f(-0.23, 0);
	glVertex2f(-0.45, -0.10);
	glEnd();

	glColor3f(0.5f, 0.5f, 0.5f);// Grey
	glBegin(GL_QUADS);
	glVertex2f(-0.45, -0.10); //Top right vertex
	glVertex2f(-0.23, 0); // Top left vertex
	glVertex2f(-0.23, -0.08); // Bottom left vertex
	glVertex2f(-0.45, -0.18); // Bottom right vertex
	glEnd();

	glColor3f(0.0f, 0.0f, 0.0f);// Black
	glBegin(GL_QUADS);
	glVertex2f(-0.45, -0.18);
	glVertex2f(-0.23, -0.08);
	glVertex2f(-0.23, -0.18);
	glVertex2f(-0.45, -0.28);
	glEnd();

	//Pillar 1
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_QUADS);
	glVertex2f(-0.34, 0.24);
	glVertex2f(-0.33, 0.25);
	glVertex2f(-0.33, -0.24);
	glVertex2f(-0.34, -0.25);
	glEnd();

	// White Wall 1
	glColor3f(0.4f, 0.89f, 0.75f); // Custom color : #65E5C0 (R=101, G=229, B=192)
	glBegin(GL_QUADS);
	glVertex2f(-0.23, -0.05);
	glVertex2f(-0.52, 0.25);
	glVertex2f(-0.52, -0.27);
	glVertex2f(-0.23, -0.27);
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_QUADS);
	glVertex2f(-0.23, -0.03);
	glVertex2f(-0.53, 0.27);
	glVertex2f(-0.53, 0.25);
	glVertex2f(-0.23, -0.05);
	glEnd();

	// Tall Pillar 1
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_QUADS);
	glVertex2f(-0.52, 0.25);
	glVertex2f(-0.53, 0.25);
	glVertex2f(-0.53, -0.8);
	glVertex2f(-0.52, -0.8);
	glEnd();

	// White Wall 2
	glColor3f(1.0f, 1.0f, 1.0f); // Custom color : #65E5C0 (R=101, G=229, B=192)
	glBegin(GL_QUADS);
	glVertex2f(-0.53, 0.23);
	glVertex2f(-0.75, 0.35);
	glVertex2f(-0.75, -0.42);
	glVertex2f(-0.53, -0.5);
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_QUADS);
	glVertex2f(-0.53, 0.25);
	glVertex2f(-0.76, 0.37);
	glVertex2f(-0.76, 0.35);
	glVertex2f(-0.53, 0.23);
	glEnd();

	// Tall Pillar 2
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_QUADS);
	glVertex2f(-0.75, 0.35);
	glVertex2f(-0.76, 0.35);
	glVertex2f(-0.76, -0.8);
	glVertex2f(-0.75, -0.8);
	glEnd();

	// White Wall 3
	glColor3f(1.0f, 1.0f, 1.0f); // Custom color : #65E5C0 (R=101, G=229, B=192)
	glBegin(GL_QUADS);
	glVertex2f(-0.76, 0.35);
	glVertex2f(-1, 0.35);
	glVertex2f(-1, -0.42);
	glVertex2f(-0.76, -0.42);
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_QUADS);
	glVertex2f(-0.76, 0.37);
	glVertex2f(-1, 0.37);
	glVertex2f(-1, 0.35);
	glVertex2f(-0.76, 0.35);
	glEnd();

	//Windows Sections (Top)
	glBegin(GL_QUADS);
	glColor4f(0.0f, 0.0f, 0.5f, 1.0f);// Navy blue
	glVertex2f(-0.78, 0.31); // Top Right Vertex
	glColor3f(1.0, 1.0, 1.0); // White
	glVertex2f(-0.78, 0.15);  // Bottom Right Vertex
	glColor4f(0.0f, 0.0f, 0.5f, 1.0f);// Navy blue
	glVertex2f(-0.87, 0.15); // Bottom Left Vertex
	glColor3f(1.0, 1.0, 1.0); // White
	glVertex2f(-0.87, 0.31); // Top Left Vertex
	glEnd();


	// Borders
	glColor3f(1.0f,1.0f, 1.0f);// White
	glBegin(GL_LINES);
	glVertex2f(-0.81, 0.31);
	glVertex2f(-0.81, 0.15);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f);// White
	glBegin(GL_LINES);
	glVertex2f(-0.84, 0.31);
	glVertex2f(-0.84, 0.15);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f);// White
	glBegin(GL_LINES);
	glVertex2f(-0.78, 0.26);
	glVertex2f(-0.87, 0.26);
	glEnd();

	// Window (Bottom)
	glBegin(GL_QUADS);
	glColor4f(0.0f, 0.0f, 0.5f, 1.0f);// Navy blue
	glVertex2f(-0.78, -0.08); // Top Right Vertex
	glColor3f(1.0, 1.0, 1.0); // White
	glVertex2f(-0.78, -0.24);  // Bottom Right Vertex
	glColor4f(0.0f, 0.0f, 0.5f, 1.0f);// Navy blue
	glVertex2f(-0.87, -0.24); // Bottom Left Vertex
	glColor3f(1.0, 1.0, 1.0); // White
	glVertex2f(-0.87, -0.08); // Top Left Vertex
	glEnd();

	// Borders
	glColor3f(1.0f, 1.0f, 1.0f);// White
	glBegin(GL_LINES);
	glVertex2f(-0.81, -0.08);
	glVertex2f(-0.81, -0.24);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f);// White
	glBegin(GL_LINES);
	glVertex2f(-0.84, -0.08);
	glVertex2f(-0.84, -0.24);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f);// White
	glBegin(GL_LINES);
	glVertex2f(-0.78, -0.13);
	glVertex2f(-0.87, -0.13);
	glEnd();

	//Windows Sections (Top Right Side)
	glBegin(GL_QUADS);
	glColor4f(0.0f, 0.0f, 0.5f, 1.0f);// Navy blue
	glVertex2f(-0.66, 0.26); // Top Right Vertex
	glColor3f(1.0, 1.0, 1.0); // White
	glVertex2f(-0.66, 0.10);  // Bottom Right Vertex
	glColor4f(0.0f, 0.0f, 0.5f, 1.0f);// Navy blue
	glVertex2f(-0.75, 0.15); // Bottom Left Vertex
	glColor3f(1.0, 1.0, 1.0); // White
	glVertex2f(-0.75, 0.31); // Top Left Vertex
	glEnd();

	// Borders
	glColor3f(1.0f, 1.0f, 1.0f);// White
	glBegin(GL_LINES);
	glVertex2f(-0.72, 0.29);
	glVertex2f(-0.72, 0.13);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f);// White
	glBegin(GL_LINES);
	glVertex2f(-0.69, 0.27);
	glVertex2f(-0.69, 0.11);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f);// White
	glBegin(GL_LINES);
	glVertex2f(-0.75, 0.26);
	glVertex2f(-0.66, 0.21);
	glEnd();

	//Windows Sections (Bottom Right Side - Left Part)
	glBegin(GL_QUADS);
	glColor4f(0.0f, 0.0f, 0.5f, 1.0f);// Navy blue
	glVertex2f(-0.69, -0.11); // Top Right Vertex
	glColor3f(1.0, 1.0, 1.0); // White
	glVertex2f(-0.69, -0.27);  // Bottom Right Vertex
	glColor4f(0.0f, 0.0f, 0.5f, 1.0f);// Navy blue
	glVertex2f(-0.75, -0.24); // Bottom Left Vertex
	glColor3f(1.0, 1.0, 1.0); // White
	glVertex2f(-0.75, -0.08); // Top Left Vertex
	glEnd();

	// Borders
	glColor3f(1.0f, 1.0f, 1.0f);// White
	glBegin(GL_LINES);
	glVertex2f(-0.72, -0.09);
	glVertex2f(-0.72, -0.26);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f);// White
	glBegin(GL_LINES);
	glVertex2f(-0.75, -0.13);
	glVertex2f(-0.69, -0.16);
	glEnd();

	//Windows Sections (Bottom Right Side - Right Part)
	glBegin(GL_QUADS);
	glColor4f(0.0f, 0.0f, 0.5f, 1.0f);// Navy blue
	glVertex2f(-0.56, -0.17); // Top Right Vertex
	glColor3f(1.0, 1.0, 1.0); // White
	glVertex2f(-0.56, -0.33);  // Bottom Right Vertex
	glColor4f(0.0f, 0.0f, 0.5f, 1.0f);// Navy blue
	glVertex2f(-0.65, -0.29); // Bottom Left Vertex
	glColor3f(1.0, 1.0, 1.0); // White
	glVertex2f(-0.65, -0.13); // Top Left Vertex
	glEnd();

	// Borders
	glColor3f(1.0f, 1.0f, 1.0f);// White
	glBegin(GL_LINES);
	glVertex2f(-0.62, -0.14);
	glVertex2f(-0.62, -0.31);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f);// White
	glBegin(GL_LINES);
	glVertex2f(-0.59, -0.16);
	glVertex2f(-0.59, -0.32);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f);// White
	glBegin(GL_LINES);
	glVertex2f(-0.56, -0.22);
	glVertex2f(-0.65, -0.18);
	glEnd();

	// Front Left Lower Wall
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_QUADS);
	glVertex2f(-0.1, -0.26);
	glVertex2f(-0.52, -0.26);
	glVertex2f(-0.52, -0.42);
	glVertex2f(-0.1, -0.42);
	glEnd();

	glColor3f(0.4f, 0.89f, 0.75f); // Custom color : #65E5C0 (R=101, G=229, B=192)
	glBegin(GL_QUADS);
	glVertex2f(0.46, -0.42);
	glVertex2f(-0.52, -0.42);
	glVertex2f(-0.52, -0.55);
	glVertex2f(0.46, -0.55);
	glEnd();

	//Window Sections (Right)
	glBegin(GL_QUADS);
	glColor4f(0.0f, 0.0f, 0.5f, 1.0f);// Navy blue
	glVertex2f(-0.17, -0.26); // Top Right Vertex
	glColor3f(1.0, 1.0, 1.0); // White
	glVertex2f(-0.17, -0.42);  // Bottom Right Vertex
	glColor4f(0.0f, 0.0f, 0.5f, 1.0f);// Navy blue
	glVertex2f(-0.26, -0.42); // Bottom Left Vertex
	glColor3f(1.0, 1.0, 1.0); // White
	glVertex2f(-0.26, -0.26); // Top Left Vertex
	glEnd();

	// Borders
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_LINES);
	glVertex2f(-0.215, -0.26);
	glVertex2f(-0.215, -0.42);
	glEnd();

	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_LINES);
	glVertex2f(-0.17, -0.31);
	glVertex2f(-0.26, -0.31);
	glEnd();

	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_LINES);
	glVertex2f(-0.17, -0.36);
	glVertex2f(-0.26, -0.36);
	glEnd();

	// Window Sections (Middle)
	glBegin(GL_QUADS);
	glColor4f(0.0f, 0.0f, 0.5f, 1.0f);// Navy blue
	glVertex2f(-0.30, -0.26); // Top Right Vertex
	glColor3f(1.0, 1.0, 1.0); // White
	glVertex2f(-0.30, -0.42);  // Bottom Right Vertex
	glColor4f(0.0f, 0.0f, 0.5f, 1.0f);// Navy blue
	glVertex2f(-0.39, -0.42); // Bottom Left Vertex
	glColor3f(1.0, 1.0, 1.0); // White
	glVertex2f(-0.39, -0.26); // Top Left Vertex
	glEnd();

	// Borders
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_LINES);
	glVertex2f(-0.345, -0.26);
	glVertex2f(-0.345, -0.42);
	glEnd();

	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_LINES);
	glVertex2f(-0.30, -0.31);
	glVertex2f(-0.39, -0.31);
	glEnd();

	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_LINES);
	glVertex2f(-0.30, -0.36);
	glVertex2f(-0.39, -0.36);
	glEnd();

	//Window Sections (Left)
	glColor4f(0.0f, 0.0f, 0.5f, 0.5f);// Navy Blue
	glBegin(GL_QUADS);
	glVertex2f(-0.43, -0.26);
	glVertex2f(-0.52, -0.26);
	glVertex2f(-0.52, -0.42);
	glVertex2f(-0.43, -0.42);
	glEnd();
	glBegin(GL_QUADS);
	glColor4f(0.0f, 0.0f, 0.5f, 1.0f);// Navy blue
	glVertex2f(-0.43, -0.26); // Top Right Vertex
	glColor3f(1.0, 1.0, 1.0); // White
	glVertex2f(-0.43, -0.42);  // Bottom Right Vertex
	glColor4f(0.0f, 0.0f, 0.5f, 1.0f);// Navy blue
	glVertex2f(-0.52, -0.42); // Bottom Left Vertex
	glColor3f(1.0, 1.0, 1.0); // White
	glVertex2f(-0.52, -0.26); // Top Left Vertex
	glEnd();

	// Borders
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_LINES);
	glVertex2f(-0.475, -0.26);
	glVertex2f(-0.475, -0.42);
	glEnd();

	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_LINES);
	glVertex2f(-0.43, -0.31);
	glVertex2f(-0.52, -0.31);
	glEnd();

	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_LINES);
	glVertex2f(-0.43, -0.36);
	glVertex2f(-0.52, -0.36);
	glEnd();

	// Grey Strip
	glColor4f(0.5f, 0.5f, 0.5f, 0.5f);// Grey
	glBegin(GL_QUADS);
	glVertex2f(-0.05, -0.26);
	glVertex2f(-0.1, -0.26);
	glVertex2f(-0.1, -0.42);
	glVertex2f(-0.05, -0.42);
	glEnd();

	//Pillar Near Strip
	glColor4f(0.0f, 0.0f, 0.0f, 0.0f);// Black
	glBegin(GL_QUADS);
	glVertex2f(-0.1, -0.26);
	glVertex2f(-0.12, -0.26);
	glVertex2f(-0.12, -0.42);
	glVertex2f(-0.1, -0.42);
	glEnd();

	//Pillar Underneath Roof
	glColor4f(0.5f, 0.0f, 0.0f, 1.0f);// Bright Red
	glBegin(GL_QUADS);
	glVertex2f(-0.09, -0.42);
	glVertex2f(-0.13, -0.42);
	glVertex2f(-0.13, -0.8);
	glVertex2f(-0.09, -0.8);
	glEnd();

	//Interiors
	glColor3f(0.4f, 0.89f, 0.75f); // Custom color : #65E5C0 (R=101, G=229, B=192)
	glBegin(GL_QUADS);
	glVertex2f(0.22, -0.35);
	glVertex2f(-0.05, -0.35);
	glVertex2f(-0.05, -0.40);
	glVertex2f(0.22, -0.40);
	glEnd();

	glColor3f(0.0f, 0.0f, 0.0f); // Black
	glBegin(GL_QUADS);
	glVertex2f(0.22, -0.26);
	glVertex2f(-0.05, -0.26);
	glVertex2f(-0.05, -0.35);
	glVertex2f(0.22, -0.35);
	glEnd();

	glColor3f(0.0f, 0.0f, 0.0f); // Black
	glBegin(GL_QUADS);
	glVertex2f(0.46, -0.3);
	glVertex2f(0.24, -0.2);
	glVertex2f(0.24, -0.35);
	glVertex2f(0.46, -0.36);
	glEnd();

	glColor3f(0.4f, 0.89f, 0.75f); // Custom color : #65E5C0 (R=101, G=229, B=192)
	glBegin(GL_QUADS);
	glVertex2f(0.46, -0.36);
	glVertex2f(0.22, -0.35);
	glVertex2f(0.22, -0.55);
	glVertex2f(0.46, -0.55);
	glEnd();

	// Staircase Entrance
	glColor3f(0.0f, 0.0f, 0.0f); // Black
	glBegin(GL_QUADS);
	glVertex2f(0.22, -0.46);
	glVertex2f(-0.05, -0.46);
	glVertex2f(-0.05, -0.55);
	glVertex2f(0.22, -0.55);
	glEnd();
	// Border (Left)
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_QUADS);
	glVertex2f(-0.05, -0.55);
	glVertex2f(-0.06, -0.55);
	glVertex2f(-0.09, -0.75);
	glVertex2f(-0.06, -0.75);
	glEnd();
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_QUADS);
	glVertex2f(-0.06, -0.75);
	glVertex2f(-0.15, -0.75);
	glVertex2f(-0.15, -0.76);
	glVertex2f(-0.06, -0.76);
	glEnd();
	glColor3f(0.4f, 0.89f, 0.75f); // Custom color : #65E5C0 (R=101, G=229, B=192)
	glBegin(GL_QUADS);
	glVertex2f(-0.06, -0.76);
	glVertex2f(-0.15, -0.76);
	glVertex2f(-0.15, -0.8);
	glVertex2f(-0.06, -0.8);
	glEnd();
	// Border (Right)
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_QUADS);
	glVertex2f(0.23, -0.55);
	glVertex2f(0.22, -0.55);
	glVertex2f(0.23, -0.75);
	glVertex2f(0.26, -0.75);
	glEnd();
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_QUADS);
	glVertex2f(0.3, -0.75);
	glVertex2f(0.23, -0.75);
	glVertex2f(0.23, -0.76);
	glVertex2f(0.3, -0.76);
	glEnd();
	glColor3f(0.4f, 0.89f, 0.75f); // Custom color : #65E5C0 (R=101, G=229, B=192)
	glBegin(GL_QUADS);
	glVertex2f(0.3, -0.76);
	glVertex2f(0.23, -0.76);
	glVertex2f(0.23, -0.8);
	glVertex2f(0.3, -0.8);
	glEnd();
	// Stairs
	glColor4f(0.5f, 0.5f, 0.5f, 0.5f);// Grey
	glBegin(GL_QUADS);
	glVertex2f(0.22, -0.55);
	glVertex2f(-0.05, -0.55);
	glVertex2f(-0.07, -0.8);
	glVertex2f(0.24, -0.8);
	glEnd();
	//Steps
	glColor3f(0.0f, 0.0f, 0.0f);// Black
	glBegin(GL_LINES);
	glVertex2f(0.225, -0.6);
	glVertex2f(-0.055, -0.6);
	glEnd();
	glColor3f(0.0f, 0.0f, 0.0f);// Black
	glBegin(GL_LINES);
	glVertex2f(0.23, -0.65);
	glVertex2f(-0.06, -0.65);
	glEnd();
	glColor3f(0.0f, 0.0f, 0.0f);// Black
	glBegin(GL_LINES);
	glVertex2f(0.234, -0.7);
	glVertex2f(-0.064, -0.7);
	glEnd();
	glColor3f(0.0f, 0.0f, 0.0f);// Black
	glBegin(GL_LINES);
	glVertex2f(0.239, -0.75);
	glVertex2f(-0.069, -0.75);
	glEnd();

	// Lower Right Wing
	glColor3f(0.4f, 0.89f, 0.75f); // Custom color : #65E5C0 (R=101, G=229, B=192)
	glBegin(GL_QUADS);
	glVertex2f(1, -0.1); // Top Right Vertex
	glVertex2f(0.44, -0.31); // Top Left Vertex
	glVertex2f(0.44, -0.55); // Bottom left Vertex
	glVertex2f(1, -0.55); // Bottom Right Vertex
	glEnd();

	// Window Sections (Left)
	glBegin(GL_QUADS);
	glColor4f(0.0f, 0.0f, 0.5f, 1.0f);// Navy blue
	glVertex2f(0.6, -0.31); // Top Right Vertex
	glColor3f(1.0, 1.0, 1.0); // White
	glVertex2f(0.6, -0.47);  // Bottom Right Vertex
	glColor4f(0.0f, 0.0f, 0.5f, 1.0f);// Navy blue
	glVertex2f(0.51, -0.5); // Bottom Left Vertex
	glColor3f(1.0, 1.0, 1.0); // White
	glVertex2f(0.51, -0.34); // Top Left Vertex
	glEnd();
	// Borders
	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_LINES); // Middle Line
	glVertex2f(0.6, -0.355);
	glVertex2f(0.51, -0.39);
	glBegin(GL_LINES); // Left Line
	glVertex2f(0.54, -0.33);
	glVertex2f(0.54, -0.49);
	glBegin(GL_LINES); // Right Line
	glVertex2f(0.57, -0.32);
	glVertex2f(0.57, -0.48);
	glEnd();

	// Window Sections (Middle)
	glBegin(GL_QUADS);
	glColor4f(0.0f, 0.0f, 0.5f, 1.0f);// Navy blue
	glVertex2f(0.74, -0.26); // Top Right Vertex
	glColor3f(1.0, 1.0, 1.0); // White
	glVertex2f(0.74, -0.42);  // Bottom Right Vertex
	glColor4f(0.0f, 0.0f, 0.5f, 1.0f);// Navy blue
	glVertex2f(0.65, -0.45); // Bottom Left Vertex
	glColor3f(1.0, 1.0, 1.0); // White
	glVertex2f(0.65, -0.29); // Top Left Vertex
	glEnd();
	// Borders
	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_LINES); // Middle Line
	glVertex2f(0.74, -0.305);
	glVertex2f(0.65, -0.34);
	glBegin(GL_LINES); // Left Line
	glVertex2f(0.68, -0.28);
	glVertex2f(0.68, -0.45);
	glBegin(GL_LINES); // Right Line
	glVertex2f(0.71, -0.27);
	glVertex2f(0.71, -0.42);
	glEnd();

	// Window Sections (Right)
	glBegin(GL_QUADS);
	glColor4f(0.0f, 0.0f, 0.5f, 1.0f);// Navy blue
	glVertex2f(0.88, -0.21); // Top Right Vertex
	glColor3f(1.0, 1.0, 1.0); // White
	glVertex2f(0.88, -0.37);  // Bottom Right Vertex
	glColor4f(0.0f, 0.0f, 0.5f, 1.0f);// Navy blue
	glVertex2f(0.79, -0.4); // Bottom Left Vertex
	glColor3f(1.0, 1.0, 1.0); // White
	glVertex2f(0.79, -0.24); // Top Left Vertex
	glEnd();
	// Borders
	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_LINES); // Middle Line
	glVertex2f(0.88, -0.255);
	glVertex2f(0.79, -0.29);
	glBegin(GL_LINES); // Left Line
	glVertex2f(0.82, -0.23);
	glVertex2f(0.82, -0.39);
	glBegin(GL_LINES); // Right Line
	glVertex2f(0.85, -0.22);
	glVertex2f(0.85, -0.38);
	glEnd();

	// Pillar 1
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_QUADS);
	glVertex2f(0.24, -0.26);
	glVertex2f(0.22, -0.26);
	glVertex2f(0.22, -0.42);
	glVertex2f(0.24, -0.42);
	glEnd();

	// Pillar 2
	glColor4f(0.0f, 0.0f, 0.0f, 0.0f);// Black
	glBegin(GL_QUADS);
	glVertex2f(-0.1, -0.26);
	glVertex2f(-0.12, -0.26);
	glVertex2f(-0.12, -0.42);
	glVertex2f(-0.1, -0.42);
	glEnd();

	// Pillar 3
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_QUADS);
	glVertex2f(0.46, -0.3);
	glVertex2f(0.44, -0.29);
	glVertex2f(0.44, -0.55);
	glVertex2f(0.46, -0.55);
	glEnd();

	// Pillar 4 (Small)
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_QUADS);
	glVertex2f(-0.195, -0.46);
	glVertex2f(-0.205, -0.46);
	glVertex2f(-0.21, -0.5);
	glVertex2f(-0.19, -0.5);
	glEnd();
	// Pillar 4 (Slab)
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_QUADS);
	glVertex2f(-0.17, -0.5);
	glVertex2f(-0.23, -0.5);
	glVertex2f(-0.23, -0.51);
	glVertex2f(-0.17, -0.51);
	glEnd();
	// Pillar 4 (Big)
	glColor3f(1.0f, 0.0f, 0.0f);// Red
	glBegin(GL_QUADS);
	glVertex2f(-0.185, -0.51);
	glVertex2f(-0.215, -0.51);
	glVertex2f(-0.23, -0.75);
	glVertex2f(-0.17, -0.75);
	glEnd();
	//Pillar 4 (Base)
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_QUADS);
	glVertex2f(-0.15, -0.75);
	glVertex2f(-0.25, -0.75);
	glVertex2f(-0.25, -0.76);
	glVertex2f(-0.15, -0.76);
	glEnd();
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_QUADS);
	glVertex2f(-0.16, -0.76);
	glVertex2f(-0.24, -0.76);
	glVertex2f(-0.24, -0.8);
	glVertex2f(-0.16, -0.8);
	glEnd();


	// Pillar 5 (Small)
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_QUADS);
	glVertex2f(0.60, -0.46);
	glVertex2f(0.59, -0.46);
	glVertex2f(0.585, -0.5);
	glVertex2f(0.605, -0.5);
	glEnd();
	// Pillar 5 (Slab)
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_QUADS);
	glVertex2f(0.625, -0.5);
	glVertex2f(0.565, -0.5);
	glVertex2f(0.565, -0.51);
	glVertex2f(0.625, -0.51);
	glEnd();
	// Pillar 5 (Big)
	glColor3f(1.0f, 0.0f, 0.0f);// Red
	glBegin(GL_QUADS);
	glVertex2f(0.610, -0.51);
	glVertex2f(0.580, -0.51);
	glVertex2f(0.565, -0.75);
	glVertex2f(0.625, -0.75);
	glEnd();
	// Pillar 5 (Base)
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_QUADS);
	glVertex2f(0.645, -0.75);
	glVertex2f(0.545, -0.75);
	glVertex2f(0.545, -0.76);
	glVertex2f(0.645, -0.76);
	glEnd();
	glColor3f(0.13f, 0.37f, 0.31f);// Hunter Green
	glBegin(GL_QUADS);
	glVertex2f(0.635, -0.76);
	glVertex2f(0.555, -0.76);
	glVertex2f(0.555, -0.8);
	glVertex2f(0.635, -0.8);
	glEnd();

	// Foyer Roof
	glColor3f(0.3f, 0.3f, 0.3f); // Custom Color : #4D4D4D (R=77, G=77, B=77)
	glBegin(GL_QUADS);
	glVertex2f(0.37, -0.15);
	glVertex2f(-0.37, -0.15);
	glVertex2f(-0.37, -0.21);
	glVertex2f(0.37, -0.21);
	glEnd();

	glColor3f(0.6f, 0.6f, 0.6f); // Custom Color : #4D4D4D (R=77, G=77, B=77)
	glBegin(GL_QUADS);
	glVertex2f(0.55, -0.21);
	glVertex2f(-0.55, -0.21);
	glVertex2f(-0.57, -0.26);
	glVertex2f(0.57, -0.26);
	glEnd();

	// Lower Foyer Roof (Red)
	glColor3f(1.0f, 0.0f, 0.0f);// Red
	glBegin(GL_QUADS);
	glVertex2f(0.7, -0.40);
	glVertex2f(-0.25, -0.40);
	glVertex2f(-0.35, -0.46);
	glVertex2f(0.8, -0.46);
	glEnd();

	// Window Template
	/*glBegin(GL_QUADS);
	glColor4f(0.0f, 0.0f, 0.5f, 0.5f);// Navy blue
	glVertex2f(, );
	glColor3f(1.0, 1.0, 1.0);// white
	glVertex2f(, );
	glColor4f(0.0f, 0.0f, 0.5f, 0.5f);// Navy blue
	glVertex2f(, );
	glColor3f(1.0, 1.0, 1.0);// white
	glVertex2f(, );
	glEnd();*/
}

void Tree() {

	// Trunk
	glColor3f(0.0f, 0.5f, 0.0f);
	glBegin(GL_TRIANGLES);
	glVertex2f(0.85, -0.75);
	glVertex2f(0.9, -0.75);
	glVertex2f(0.875, -0.25);
	
	glVertex2f(0.9, -0.45);
	glVertex2f(0.85, -0.45);
	glVertex2f(0.875, -0.2);
	// Branch 1
	glVertex2f(0.9, -0.25);
	glVertex2f(0.85, -0.25);
	glVertex2f(0.775, -0.05);
	// Branch 2
	glVertex2f(0.9, -0.34);
	glVertex2f(0.85, -0.25);
	glVertex2f(0.815, 0.24);
	// Branch 3
	glVertex2f(0.9, -0.25);
	glVertex2f(0.85, -0.36);
	glVertex2f(0.9,0);
	glEnd();
	//Leaves
	glColor3f(0.0f, 0.7f, 0.0f);// Light Green
	Circle1(0.775, -0.05, 0.13);
	Circle1(0.775, 0.09, 0.13);
	Circle1(0.820, 0.02, 0.13);
	Circle1(0.815, 0.24, 0.14);
	Circle1(0.885, 0.23, 0.14);
	Circle1(0.792, 0.22, 0.14);
	Circle1(0.9, 0, 0.12);
	Circle1(0.94, 0.02, 0.12);
	Circle1(0.87, 0.08, 0.12);
}

void display(void) {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);  //Clear the colour buffer and depth buffer
	glColor3d(1, 0, 0);
	glLoadIdentity(); // Load the Identity Matrix to reset our drawing locations 
	glMatrixMode(GL_MODELVIEW); // Use the Modelview Matrix

	// call the function of the objects
	Sky();
	Grassfield();
	Road();
	Cloud1();
	Sun();
	Building();
	Tree();

	glFlush(); // Flush the OpenGL buffers to the window 
	glutSwapBuffers();

}

int main(int argc, char** argv) {
	glutInit(&argc, argv); // Initialize GLUT 
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowSize(1280, 720); // Set the width and height of the window 
	glutInitWindowPosition(50, 50); // Set the position of the window 
	glutCreateWindow("N28 (1280x720 16:9)"); // Set the title for the window 

	init();// call the initial condition function
	glutDisplayFunc(display); // Tell GLUT to use the method "display" for rendering 
	glutReshapeFunc(changeSize);
	glutMainLoop(); // Enter GLUT's main loop 

	return 0;
}